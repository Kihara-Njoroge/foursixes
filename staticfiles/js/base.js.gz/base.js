const nav_item_count_ele = document.getElementById('bag-count');
function update_nav_item_count(itemcount){
    nav_item_count_ele.innerText = itemcount;
}